
part of values;


class Radii {
  static const BorderRadiusGeometry k2pxRadius = BorderRadius.all(Radius.circular(2));
}