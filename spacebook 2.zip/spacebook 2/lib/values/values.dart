library values;

import 'package:flutter/widgets.dart';

part 'colors.dart';
part 'radii.dart';
part 'shadows.dart';