
import 'package:flutter/material.dart';
import 'package:untitled_2_2/android_mobile1_widget/android_mobile1_widget.dart';

void main() => runApp(App());


class App extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
  
    return MaterialApp(
      home: AndroidMobile1Widget(),
    );
  }
}