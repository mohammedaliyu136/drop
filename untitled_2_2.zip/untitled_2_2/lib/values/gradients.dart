
part of values;


class Gradients {
  static const Gradient primaryGradient = LinearGradient(
    begin: Alignment(0, 1),
    end: Alignment(0, 2),
    stops: [
      0,
      0,
      0.83672,
      1,
    ],
    colors: [
      Color.fromARGB(255, 255, 255, 255),
      Color.fromARGB(255, 254, 242, 230),
      Color.fromARGB(255, 249, 170, 95),
      Color.fromARGB(255, 248, 156, 69),
    ],
  );
}