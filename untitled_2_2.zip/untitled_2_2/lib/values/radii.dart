
part of values;


class Radii {
  static const BorderRadiusGeometry k18pxRadius = BorderRadius.all(Radius.circular(18));
}