
part of values;


class AppColors {
  static const Color primaryBackground = Color.fromARGB(255, 255, 255, 255);
  static const Color secondaryBackground = Color.fromARGB(255, 245, 245, 245);
  static const Color primaryElement = Color.fromARGB(255, 255, 255, 255);
  static const Color secondaryElement = Color.fromARGB(135, 183, 183, 183);
  static const Color accentElement = Color.fromARGB(255, 245, 151, 63);
  static const Color primaryText = Color.fromARGB(255, 70, 70, 70);
  static const Color secondaryText = Color.fromARGB(255, 104, 104, 104);
  static const Color accentText = Color.fromARGB(255, 255, 255, 255);
}