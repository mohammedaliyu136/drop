
import 'package:flutter/material.dart';
import 'package:untitled_2_2/android_mobile1_widget/android_mobile1_widget.dart';
import 'package:untitled_2_2/values/values.dart';


class AndroidMobile4Widget extends StatelessWidget {
  
  void onLoginBtnPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => AndroidMobile1Widget()));
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 183, 153, 127),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(
              top: 226,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: 305,
                      height: 51,
                      decoration: BoxDecoration(
                        color: AppColors.secondaryElement,
                      ),
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: "Username",
                          contentPadding: EdgeInsets.all(0),
                          border: InputBorder.none,
                        ),
                        style: TextStyle(
                          color: Color.fromARGB(255, 112, 112, 112),
                          fontWeight: FontWeight.w400,
                          fontSize: 20,
                        ),
                        maxLines: 1,
                        autocorrect: false,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: 305,
                      height: 51,
                      margin: EdgeInsets.only(top: 87),
                      child: FlatButton(
                        onPressed: () => this.onLoginBtnPressed(context),
                        color: Color.fromARGB(255, 133, 32, 32),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(0)),
                        ),
                        textColor: Color.fromARGB(255, 255, 255, 255),
                        padding: EdgeInsets.all(0),
                        child: Text(
                          "Login",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            color: AppColors.accentText,
                            fontWeight: FontWeight.w400,
                            fontSize: 20,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              child: Container(
                width: 305,
                height: 51,
                decoration: BoxDecoration(
                  color: AppColors.secondaryElement,
                ),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: "Password",
                    contentPadding: EdgeInsets.all(0),
                    border: InputBorder.none,
                  ),
                  style: TextStyle(
                    color: Color.fromARGB(255, 112, 112, 112),
                    fontWeight: FontWeight.w400,
                    fontSize: 20,
                  ),
                  obscureText: true,
                  maxLines: 1,
                  autocorrect: false,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}