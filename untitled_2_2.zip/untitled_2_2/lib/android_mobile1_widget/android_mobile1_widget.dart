
import 'package:flutter/material.dart';
import 'package:untitled_2_2/values/values.dart';


class AndroidMobile1Widget extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
  
    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 183, 153, 127),
        ),
        child: Stack(
          children: [
            Positioned(
              left: -49,
              top: -4,
              right: -99,
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  Positioned(
                    top: 219,
                    right: 102,
                    child: Container(
                      width: 129,
                      height: 106,
                      decoration: BoxDecoration(
                        color: AppColors.primaryBackground,
                        borderRadius: BorderRadius.all(Radius.circular(50)),
                      ),
                      child: Container(),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 228,
                    right: 0,
                    child: Image.asset(
                      "assets/images/ellipse-2.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                  Positioned(
                    top: 235,
                    right: 145,
                    child: Container(
                      width: 53,
                      height: 47,
                      decoration: BoxDecoration(
                        color: AppColors.primaryElement,
                        borderRadius: BorderRadius.all(Radius.circular(23.5)),
                      ),
                      child: Container(),
                    ),
                  ),
                  Positioned(
                    top: 142,
                    right: 68,
                    child: Container(
                      width: 211,
                      height: 116,
                      decoration: BoxDecoration(
                        gradient: Gradients.primaryGradient,
                        borderRadius: BorderRadius.all(Radius.circular(58)),
                      ),
                      child: Container(),
                    ),
                  ),
                  Positioned(
                    top: 0,
                    right: 172,
                    child: Container(
                      width: 3,
                      height: 145,
                      decoration: BoxDecoration(
                        color: AppColors.accentElement,
                      ),
                      child: Container(),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              left: 26,
              top: 195,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "Power",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: AppColors.accentText,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        letterSpacing: 0.728,
                      ),
                    ),
                  ),
                  Container(
                    height: 36,
                    margin: EdgeInsets.only(top: 8),
                    decoration: BoxDecoration(
                      color: AppColors.primaryElement,
                      borderRadius: Radii.k18pxRadius,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          width: 34,
                          height: 33,
                          margin: EdgeInsets.only(right: 3),
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 142, 131, 119),
                            borderRadius: BorderRadius.all(Radius.circular(16.5)),
                          ),
                          child: Container(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}